#include "A.h"
#include "B.h"
#include "C.h"

int main(){
    A a;
    B b;
    C c;
    
    a.A2();
    b.B1();
    c.C1();
    
    return 0;
}