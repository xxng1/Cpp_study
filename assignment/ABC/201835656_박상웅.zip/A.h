#ifndef A_H
#define A_H

class A {
public:
    void A1();
    void A2();
    void A3();
};

#endif
