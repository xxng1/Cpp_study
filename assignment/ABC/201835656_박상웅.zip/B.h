#ifndef B_H
#define B_H

class B {
public:
    void B1();
    void B2();
};

#endif