#ifndef C_H
#define C_H

class C {
public:
    void C1();
};

#endif